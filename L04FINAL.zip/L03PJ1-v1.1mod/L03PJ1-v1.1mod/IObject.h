#pragma once
#include "IShape2D.h"
#include "IPosition2D.h"

class IObject : virtual public IShape2D, virtual public IPosition2D, virtual public ICloneable {
public:
	//SVI ELEMENTI TREBAJU IMATI NASLIJEDJENJE OSOBINE OVA DVA
	//virtual void setPerimeterComparison(bool) = 0;
	//virtual bool getPerimeterComparison() const = 0;

	virtual bool operator==(const IObject& other) const = 0;

	virtual bool operator<(const IObject& other) const {
		if (this->computePerimeter() < other.computePerimeter())
			return true;
		
		return false;
	}

	virtual bool operator<=(const IObject& other) const {
		if (this->computePerimeter() <= other.computePerimeter())
			return true;

		return false;
	}

	virtual bool operator>(const IObject& other) const {
		return !(*this < other);
	}

	virtual bool operator>=(const IObject& other) const {
		return !(*this <= other);
	}

	virtual IObject* clone() const = 0;
};