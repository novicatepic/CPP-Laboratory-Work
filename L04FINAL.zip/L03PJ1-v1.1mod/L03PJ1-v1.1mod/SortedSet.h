#pragma once
#include <iostream>
#include "IObject.h"
#include "GenericSet.h"

template <typename T>
concept Comparable = requires(const T & t1, const T & t2) {
	{t1 < t2} -> std::convertible_to<bool>;
	{t1 <= t2} -> std::convertible_to<bool>;
	{t1 > t2} -> std::convertible_to<bool>;
	{t1 >= t2} -> std::convertible_to<bool>;
};

template <class T>
requires Comparable<T>
class SortedSet : virtual public Set<T> {
private:
public:
	SortedSet() : Set<T>() { }

	void add(const T& other) {
		Set<T>::add(other);
		this->sortElements();
	}


	bool tryAdd(const T& other) {
		if (Set<T>::tryAdd(other)) {
			this->sortElements();
			return true;
		}
		return false;
	}

private:
	//CONST NE RADI
	void sortElements()  {
		for (size_t i = 0; i < this->arrLen - 1; i++) {
			for (size_t j = i; j < this->arrLen; j++) {
				if (*this->arr[i] > *this->arr[j]) {
					//T* temp = dynamic_cast<T*>(this->arr[i]);
					//this->arr[i] = dynamic_cast<T*>(this->arr[j]);
					//this->arr[j] = dynamic_cast<T*>(temp);
					T* temp = this->copyHelp(*this->arr[i]);
					this->arr[i] = this->copyHelp(*this->arr[j]);
					this->arr[j] = this->copyHelp(*temp);
				}
			}
		}
	}
};


//IMPLEMENTACIJA KOJA MOZE POSLUZITI DA SE U NIZ DODAJU SAMO ELEMENTI KOJI SE MOGU SORTIRATI IZ IOBJECT
//UMJESTO IOBJECT SAM MOGAO STAVITI I T, IMALO BI VISE SMISLA
//NI PERIMETER COMPARISON OVDJE NEMA SMISLA, AKO JE T KAKO CEMO ZNATI STA CE PROGRAM KORISTITI?
//ISPRAVITI PO POTREBI NA MODIFIKACIJI
/*class SortedSet : virtual public Set<IObject> {
private:
	bool perimeterComparison;

public:
	SortedSet(bool perimeterComparison = true) : Set<IObject>() {
		this->perimeterComparison = perimeterComparison;
	}

	template <class T>
	requires Comparable<T>
	void add(const T& other) {
		this->Set::add(other);
		this->sortElements();
	}

	template <class T>
	requires Comparable<T>
	bool tryAdd(const T& other) {
		if (this->Set::tryAdd(other)) {
			this->sortElements();
			return true;
		}
		return false;
	}

private:
	//OVDJE BI SE TREBAO KORISTITI OPERATOR POREDJENJA >, NEMA SMISLA KORISTITI F-JE
	//ZA KOJE NE ZNAMO DA POSTOJE
	//OPERATOR SA DRUGE STRANE MORA POSTOJATI
	void sortElements() const {
		if (this->perimeterComparison == true) {
			for (size_t i = 0; i < this->arrLen - 1; i++) {
				for (size_t j = i; j < this->arrLen; j++) {
					if (this->arr[i]->computePerimeter() > this->arr[j]->computePerimeter()) {
						IObject* temp = dynamic_cast<IObject*>(this->arr[i]);
						this->arr[i] = dynamic_cast<IObject*>(this->arr[j]);
						this->arr[j] = dynamic_cast<IObject*>(temp);
					}
				}
			}
		}
		else {
			for (size_t i = 0; i < this->arrLen - 1; i++) {
				for (size_t j = i; j < this->arrLen; j++) {
					if (this->arr[i]->computeDistance() > this->arr[j]->computeDistance()) {
						IObject* temp = dynamic_cast<IObject*>(this->arr[i]);
						this->arr[i] = dynamic_cast<IObject*>(this->arr[j]);
						this->arr[j] = dynamic_cast<IObject*>(temp);
					}
				}
			}
		}
	}
};*/