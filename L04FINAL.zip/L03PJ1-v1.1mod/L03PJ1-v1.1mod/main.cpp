#include <iostream>
#include "Coordinates.h"
#include "Rectangle.h"
#include "Square.h"
#include "Circle.h"
#include "Polygon.h"
#include "ICollection.h"
/*#include "UnlimitedUnsortedSet.h"
#include "UnlimitedSortedSet.h"
#include "UnlimitedComparableSet.h"
#include "UnlimitedSortedAndComparableSet.h"*/
//#include "IObject.h"
#include "GenericSet.h"
#include "SortedSet.h"
#include "UnlimitedSortedSet.h"

/*IObject* tryTransform(const IObject& object) {
	const Circle* c = dynamic_cast<const Circle*>(&object);

	if (c != nullptr) {
		Coordinate A(c->getCenter().getXCoordinate() - c->getR(), c->getR() / 2);
		Coordinate D(c->getCenter().getXCoordinate() + c->getR(), c->getR() * 2);
		Rectangle *r = new Rectangle(A, D);
		return r;
	}
	IObject* clone = dynamic_cast<IObject*>(object.clone());
	return clone;
	//return &object;
}*/

int main() {
	Coordinate A(0, 0);
	Coordinate D(2, 2);
	Coordinate C(5, 5);
	Coordinate A1(2, 2);
	Coordinate D1(12, 12);
	Rectangle r(A, D);
	Rectangle r2(A1, D1);
	Coordinate F(6, 6); 
	Coordinate F1(0, 0);
	Square s(F1, F);
	Square s2(A, C);
	Square s3(A, D1);
	Circle c(A, 2.2);
	Circle c2(C, 5.5);
	Polygon p(0, nullptr);
	Rectangle r5(A, D);
	Coordinate A4(4, 1);
	Coordinate D4(3, 8);
	Coordinate C4(3, 4);
	Coordinate F4(7, 8);
	Coordinate* array = new Coordinate[4];
	array[0] = A4;
	array[1] = D4;
	array[2] = C4;
	array[3] = F4;
	Polygon pokusaj(4, array);

	Rectangle r3(A4, D4);

	/*Set<int> set;
	set.add(4);
	set.add(6);
	set.add(8);
	set.remove(8);
	std::cout << set << std::endl;

	Set<IObject> set2;
	set2.add(r);
	set2.add(c);
	set2.add(pokusaj);
	set2.remove(r);
	//set2.remove(r);
	std::cout << set2 << std::endl;

	Set<Rectangle> set3;
	//set3.add(r);
	//std::cout << set3 << std::endl;
	*/
	Set<IObject> set;
	set.add(r);
	
	try {
		set.add(r);
	}
	catch (const std::exception& e) {
		std::cout << e.what() << std::endl;
	}

	set.tryAdd(r);

	set.add(s);
	set.add(pokusaj);

	try {
		set.remove(s);
	}
	catch (const std::exception& e) {
		std::cout << e.what() << std::endl;
	}

	try {
		set.remove(s);
	}
	catch (const std::exception& e) {
		std::cout << e.what() << std::endl;
	}

	set.tryRemove(s);
	//set.remove(s);
	//set.remove(s);
	
	std::cout << set << std::endl;

	set.remove(pokusaj);
	std::cout << std::endl;

	std::cout << set << std::endl;

	Set<Rectangle> set2;
	//set2.add(r);

	Set<IObject> setCopy = set;

	//std::cout << setCopy << std::endl;

	SortedSet<IObject> sortedSet;
	
	sortedSet.tryAdd(r);
	sortedSet.add(r2);
	sortedSet.add(r3);

	try {
		set.add(r2);
	}
	catch (const std::exception& e) {
		std::cout << e.what() << std::endl;
	}

	sortedSet.add(c);

	sortedSet.tryAdd(r2);
	sortedSet.tryAdd(r2);
	sortedSet.tryAdd(pokusaj);
	sortedSet.add(c2);
	
	std::cout << std::endl; 
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	//std::cout << sortedSet;
	//std::cout << std::endl;
	//std::cout << std::endl;

	SortedSet<Rectangle> sortedRectangle; //Rectangle ima svoje operatore poredjenja
	sortedRectangle.add(r2);
	sortedRectangle.add(r);
	//sortedRectangle.add(r);
	sortedRectangle.tryAdd(r3);

	//std::cout << sortedRectangle << std::endl;

	SortedSet<Circle> sortedCircles; //Nema svoje operatore poredjenja, ali ih nasljedjuje
	sortedCircles.add(c);
	sortedCircles.add(c2);
	//std::cout << sortedCircles << std::endl;

	//INT TEST
	Set<int> setInt;
	setInt.add(4);
	setInt.add(2);
	setInt.add(8);
	setInt.add(9);
	setInt.add(10);
	setInt.add(400);
	//std::cout << setInt << std::endl;

	SortedSet<int> sortedInt;
	sortedInt.add(400);
	sortedInt.add(2);
	sortedInt.add(222);
	//std::cout << sortedInt << std::endl;

	SortedSet<char> sortedChar;
	sortedChar.add('A');
	sortedChar.add('C');
	sortedChar.add('B');
	sortedChar.remove('B');
	sortedChar.remove('A');
	try {
		sortedChar.remove('A');
	}
	catch (const std::exception& e) {
		std::cout << e.what() << std::endl;
	}
	sortedChar.remove('C');
	std::cout << sortedChar << std::endl;

	SortedSet<Rectangle> rectangleSet;
	rectangleSet.add(r3);
	rectangleSet.add(r);
	rectangleSet.add(r2);
	//std::cout << rectangleSet << std::endl;

	SortedSet<std::string> stringSet;
	stringSet.add("Zoren");
	stringSet.add("RRRR");
	stringSet.add("Bogoya");
	std::cout << stringSet << std::endl;

	return 0;
}