#pragma once
#include <iostream>
#include <functional>
#include "Exceptions.h"
#include "Concepts.h"

template <class T>
class Set : virtual public IPrintable {
protected:
	size_t arrLen;
	T** arr;
public:
	Set() : arrLen(0), arr(nullptr) {}

	Set(const Set& other) : arrLen(other.arrLen), arr(new T* [other.arrLen]) {
		this->copy(other);
	}

	Set(Set&& other) : arrLen(other.arrLen), arr(other.arr) {
		other.arr = nullptr;
		other.arrLen = 0;
	}

	Set& operator=(const Set& other) {
		if (this == &other)
			return *this;

		this->dispose();
		this->arr = new T * [other.arrLen];
		this->arrLen = other.arrLen;
		this->copy(other);
		return *this;
	}

	Set& operator=(Set&& other) {
		if (this == &other)
			return *this;

		this->arr = other.arr;
		this->arrLen = other.arrLen;
		other.arr = nullptr;
		other.arrLen = 0;

		return *this;
	}

	virtual ~Set() {
		this->dispose();
	}

	/*void add(const T& other) noexcept(false) {
		try {
			if (checkForAdding(other)) {
				throw InvalidAdd();
			}

			if (this->arr == nullptr)
				this->arr = new T * [1];
			else
				realloc(this->arrLen + 1);

			this->arr[this->arrLen] = dynamic_cast<T*>(other.clone());
			this->arrLen++;

		}

		catch (const std::exception& e) {
			std::cout << e.what() << std::endl;
		}	
	}*/

	void add(const T& other) noexcept(false) {
		if (checkForAdding(other)) {
			throw InvalidAdd("Duplicate not allowed in set!");
		}

		if (this->arr == nullptr)
			this->arr = new T * [1];
		else
			realloc(this->arrLen + 1);

		this->arr[this->arrLen] = this->copyHelp(other);
		this->arrLen++;

	}

	bool tryAdd(const T& other) noexcept {
		if (checkForAdding(other)) {
			std::cout << "Invalid add, returning false!" << std::endl;
			return false;
		}

		if (this->arr == nullptr)
			this->arr = new T * [1];
		else
			realloc(this->arrLen + 1);

		this->arr[this->arrLen] = this->copyHelp(other);
		this->arrLen++;

		return true;
	}

	/*void remove(const T& other) noexcept(false) {
		int i;
		for (i = 0; i < arrLen && *this->arr[i] != other; i++) {
			if (*this->arr[i] == other)
				break;
		}

		try {
			if (i == this->arrLen) {
				throw InvalidRemove();
			}

			for (size_t j = i; j < this->arrLen - 1; j++) {
				delete this->arr[j];
				this->arr[j] = dynamic_cast<T*>(this->arr[j + 1]->clone());
			}

			delete this->arr[this->arrLen - 1];
			this->arr[this->arrLen - 1] = nullptr;
			realloc(this->arrLen - 1);
		}
		
		catch (const std::exception& e) {
			std::cout << e.what() << std::endl;
		}
		
	}*/

	void remove(const T& other) noexcept(false) {
		int i;
		for (i = 0; i < arrLen && *this->arr[i] != other; i++) {
			if (*this->arr[i] == other)
				break;
		}

		if (i == this->arrLen) {
			throw InvalidRemove("Can't remove element that doesn't exist!");
		}

		for (size_t j = i; j < this->arrLen - 1; j++) {
			delete this->arr[j];
			this->arr[j] = this->copyHelp(*this->arr[j + 1]);
		}

		delete this->arr[this->arrLen - 1];
		this->arr[this->arrLen - 1] = nullptr;
		realloc(this->arrLen - 1);
	}

	bool tryRemove(const T& other) noexcept {
		int i;
		for (i = 0; i < arrLen && *this->arr[i] != other; i++) {
			if (*this->arr[i] == other)
				break;
		}

		if (i == this->arrLen) {
			std::cout << "Can't remove element that doesn't exist, returning false!" << std::endl;
			return false;
		}

		for (size_t j = i; j < this->arrLen - 1; j++) {
			delete this->arr[j];
			this->arr[j] = this->copyHelp(*this->arr[j + 1]);
		}

		delete this->arr[this->arrLen - 1];
		this->arr[this->arrLen - 1] = nullptr;
		realloc(this->arrLen - 1);

		return true;
	}

	virtual void print(std::ostream& os) const override {
		this->forEach([&os](const T& object) {
			os << object << std::endl;
			});
	}

	void print() const {
		this->forEach([](const T& object) {
			std::cout << object << std::endl;
			});
	}
	
	void forEach(const std::function<void(T&)>&) {
		for (int i = 0; i < this->arrLen; i++) {
			f(*this->arr[i]);
		}
	}

	void forEach(const std::function<void(const T&)>&f) const {
		for (int i = 0; i < this->arrLen; i++) {
			f(*this->arr[i]);
		}
	}
protected:
	void dispose() {
		for (size_t i = 0; i < this->arrLen; i++)
			delete this->arr[i];

		delete[] this->arr;
	}

	void copy(const Set& other) {
		for (int i = 0; i < other.arrLen; i++) {
			//this->arr[i] = dynamic_cast<T*>(other.arr[i]->clone());
			this->arr[i] = this->copyHelp(*other.arr[i]);
		}
	}

	


	bool checkForAdding(const T& other) const {
		for (int i = 0; i < this->arrLen; i++)
			if (*this->arr[i] == other)
				return true;

		return false;
	}

	void realloc(size_t newCapacity) {
		T** newArr = new T * [newCapacity];
		size_t newLength = this->arrLen < newCapacity ? this->arrLen : newCapacity;
		this->arrLen = newLength;
		for (int i = 0; i < newLength; i++) {
			newArr[i] = copyHelp(*this->arr[i]);
			//newArr[i] = this->arr[i];
		}
		delete[] this->arr;
		this->arr = newArr;
	}

	T* copyHelp(const T& value) {
		if constexpr (Cloneable<T>)
			return value.clone();
		else if constexpr (std::copy_constructible<T>)
			return new T(value);
		else
			static_assert(false, "Object is not copiable in polymorphic fashion!");
	}
};