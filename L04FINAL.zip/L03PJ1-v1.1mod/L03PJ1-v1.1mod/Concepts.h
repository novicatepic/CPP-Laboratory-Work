#pragma once
#include <concepts>
#include <iostream>

	template <typename T>
	concept Cloneable = requires(const T& t)
	{
		{t.clone()} -> std::convertible_to<T*>;
	};

	/*template <typename T>
	concept PolymorphicallyCopiable =
		Cloneable<T> || (std::copy_constructible<T> && (!std::is_class_v<T> || std::is_final_v<T>));*/

	/*template <typename T>
	concept Printable = requires(std::ostream & os, const T & obj)
	{
		{os << obj } -> std::convertible_to<decltype(os)>;
	};*/