#pragma once
#include <iostream>
#include <exception>

//throw std::exception("")
//throw std::runtime_error("")
//throw std::bad_cast("")
//catch(const std::bad_cast& e)
//throw std::invalid_argument("")
//throw std::out_of_range("")

//IMPLEMENTACIJA KOD PROFESORA
/*class InvalidAdd : public std::exception {
	
public:
	InvalidAdd() : std::exception("Can't add duplicate in set!") {}
};

class InvalidRemove : public std::exception {

public:
	InvalidRemove() : std::exception("Can't remove element that doesn't exist!") {}
};*/


//IMPLEMENTACIJA NA AUDITORNIM VJEZBAMA
class InvalidAdd : public std::exception {
public:
	using std::exception::exception;
};

class InvalidRemove : public std::exception {
public:
	using std::exception::exception;
};