#include <iostream>
#include <functional>
#include "Coordinates.h"
#include "Rectangle.h"
#include "Square.h"
#include "Circle.h"
#include "Polygon.h"
#include "ICollection.h"
#include "UnlimitedUnsortedSet.h"
#include "UnlimitedSortedSet.h"
#include "UnlimitedComparableSet.h"
#include "UnlimitedSortedAndComparableSet.h"

IObject* tryTransform(const IObject& object) {
	const Circle* c = dynamic_cast<const Circle*>(&object);

	if (c != nullptr) {
		Coordinate A(c->getCenter().getXCoordinate() - c->getR(), c->getR() / 2);
		Coordinate D(c->getCenter().getXCoordinate() + c->getR(), c->getR() * 2);
		Rectangle *r = new Rectangle(A, D);
		return r;
	}
	IObject* clone = dynamic_cast<IObject*>(object.clone());
	return clone;
	//return &object;
}

int main() {
	Coordinate A(0, 0);
	Coordinate D(2, 2);
	Coordinate C(5, 5);
	Coordinate A1(2, 2);
	Coordinate D1(12, 12);
	Rectangle r(A, D);
	Rectangle r2(A1, D1);
	Coordinate F(6, 6); 
	Coordinate F1(0, 0);
	Square s(F1, F);
	Square s2(A, C);
	Square s3(A, D1);
	Circle c(A, 2.2);
	Circle c2(C, 5.5);
	Polygon p(0, nullptr);
	Rectangle r5(A, D);
	Coordinate A4(4, 1);
	Coordinate D4(3, 8);
	Coordinate C4(3, 4);
	Coordinate F4(7, 8);
	Coordinate* array = new Coordinate[4];
	array[0] = A4;
	array[1] = D4;
	array[2] = C4;
	array[3] = F4;
	Polygon pokusaj(4, array);

	USCSet set(false);
	set.add(r);
	set.add(c);
	set.add(c2);
	set.add(s);
	set.add(pokusaj);
	set.add(r2);
	//set.remove(pokusaj);
	//set.remove(pokusaj);
	//set.remove(r2);
	//set.remove(r);
	//set.remove(r);
	//set.remove(r2);
	//set.remove(s3);
	//set.remove(s);

	//std::cout << set << std::endl;
	//set2.add(r);
	//set2.add(c);
	//set2.add(c2);
	//set2.add(s);
	//set2.add(pokusaj);
	//set2.add(r2);
	//if (set <= set2)
		//std::cout << "True" << std::endl;
	//UCSet set3 = set2;
	//std::cout << set3 << std::endl;
	//set2.add(r2);

	set.remove(s);
	set.remove(s);
	set.add(r2);
	USCSet set2 = set;
	//std::cout << set2;
	//set.transformElements(tryTransform);
	//ICollection *newC = set3.transformToNewCollection(tryTransform);
	//std::cout << set << std::endl;
	//set2.transformElements(tryTransform);
	//std::cout << set2 << std::endl;
	//std::cout << *newC << std::endl;



	ICollection* filterElements = set.filterElements("Circle");
	//std::cout << *filterElements << std::endl;

	//std::cout << set << std::endl;
	//set.transformElements(tryTransform);
	//ICollection* newTransfrom = set.transformToNewCollection(tryTransform);
	//std::cout << *newTransfrom << std::endl;
	//std::cout << set << std::endl;
	//std::cout << *find << std::endl;

	return 0;
}