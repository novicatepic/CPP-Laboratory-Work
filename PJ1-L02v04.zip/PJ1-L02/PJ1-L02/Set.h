#include "Rectangle.h"
#include <iostream>
//#include "Coordinates.h"

#pragma once

class Set {
private:
	int arraySize;
	int capacity;
	Rectangle* arr;
	//friend Rectangle;
	
public:
	Set();
	Set(int arrSize, int cap, Rectangle* arr);
	Set(const Set& other);
	Set(Set&& other);
	Set& operator=(const Set& other);
	Set& operator=(Set&& other);
	~Set();
	Set add(const Rectangle& r) const;
	Set& operator+=(const Rectangle& r);
	Set operator+(const Rectangle& r) const;
	Set remove(const Rectangle& r) const;
	//friend Set& operator+(Set& s, const Rectangle& r);
	Set& operator-=(const Rectangle& r);
	//friend Set& operator-(Set& s, const Rectangle& r);
	Set operator-(const Rectangle& r) const;
	friend std::ostream& operator<<(std::ostream& os, const Set& s);
	//std::ostream& operator<<(std::ostream& os) const;
	bool operator==(const Set& s) const;
	//void realloc();


private:
	void realloc();
	void realloc(int newCap);
	void dispose();
	bool isInSet(const Rectangle& r, int *index) const;
	bool shouldShrink() const;
	bool isInSet(const Rectangle& r) const;
	Set copySet() const;
};