#include <iostream>
#include "Coordinates.h"
#include "Rectangle.h"
#include "Set.h"

std::ostream& operator<<(std::ostream& os, const Set& s) {
	for (int i = 0; i < s.arraySize; i++) {
		os << "Ispis " << i + 1 << ".pravougaonika: " << std::endl;
		os << "((" << s.arr[i].getCenter().getXCoordinate() << ", "
			<< s.arr[i].getCenter().getYCoordinate() << "), " << s.arr[i].getA() << ", " << s.arr[i].getB() << ")" << std::endl;
	}
	return os;
}

/*Set& operator+(Set& s, const Rectangle& r) {
	if (s.isInSet(r)) {
		std::cout << "Nemoguce dodati u set, vec postoji dati pravougaonik!" << std::endl;
		return s;
	}
	else {
		if (s.arraySize >= s.capacity) {
			s.realloc();
		}

		s.arr[s.arraySize] = r;
		s.arraySize++;

		return s;
	}
}*/

/*Set& operator-(Set& s, const Rectangle& r) {
	int index;
	if (s.arraySize == 0 || !s.isInSet(r, &index)) {
		std::cout << "Nemoguce ukloniti jer nema pravougaonika u nizu ili je niz prazan!" << std::endl;
		return s;
	}
	else {
		s.isInSet(r, &index);
		for (int i = index; i < s.arraySize; i++) {
			s.arr[i] = s.arr[i + 1];
		}

		s.arraySize--;

		if (s.shouldShrink()) {
			s.realloc(s.arraySize);
		}

		return s;
	}
}*/

int main() {
	Coordinate a(0, 0);
	Coordinate b(3, 0);
	Coordinate c(0, 3);
	Coordinate d(3, 3);
	Rectangle r1(a, b, c, d);
	Coordinate a1(0, 0);
	Coordinate b1(4, 0);
	Coordinate c1(0, 1);
	Coordinate d1(4, 1);
	Rectangle r2(a1, b1, c1, d1);
	//Rectangle presjek = r1 & r2;
	//presjek.printRectangle();
	//Rectangle zbir = r1 + r2;
	//zbir.printRectangle();
	//r1 = r1 * 0;
	//r1.printRectangle();
	/*Coordinate a3(0, 0);
	Coordinate b3(6, 0);
	Coordinate c3(0, 1);
	Coordinate d3(6, 1);
	Rectangle r3(a3, b3, c3, d3);

	Rectangle add = r1 + r2;
	Rectangle intersect = r1 & r2;
	add.printRectangle();
	intersect.printRectangle();
	r1 = r1 * 2;

	r1.printRectangle();
	*/
	Set s;
	s = s + r1;
	s += r2;
	s += r1;
	s = s + r2;
	//s += r3;
	std::cout << s;
	Set s2;
	s2 += r2;
	s2 = s2 + r2;
	s2 = s2 + r1;
	//s2 = s2 + r3;
	std::cout << s2;
	if (s == s2) {
		std::cout << "Setovi su jednaki!" << std::endl; //ispise
	}
	s2 -= r2;
	s2 = s2 - r2;
	s2 = s2 - r2;
	s2 = s2 + r1;
	if (s == s2) {
		std::cout << "Setovi su jednaki!" << std::endl; //ne ispise 
	}
	return 0;
}