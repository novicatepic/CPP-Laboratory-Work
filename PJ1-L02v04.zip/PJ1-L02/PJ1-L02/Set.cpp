#include "Set.h"
#include <iostream>

Set::Set() : arraySize(0), capacity(0), arr(nullptr) {}

Set::Set(int arrSize, int cap, Rectangle* arr) {
	this->arraySize = arrSize;
	this->capacity = cap;
	for (int i = 0; i < this->arraySize; i++) {
		this->arr[i] = arr[i];
	}
}

Set::Set(const Set& other) {
	arraySize = other.arraySize;
	capacity = other.capacity;
	arr = new Rectangle[arraySize];
	for (int i = 0; i < arraySize; i++)
		arr[i] = other.arr[i];
}

Set::~Set() {
	this->dispose();
}

Set::Set(Set&& other) : arraySize(other.arraySize), capacity(other.capacity), arr(other.arr) {
	other.arr = nullptr;
	other.arraySize = 0;
	other.capacity = 0;
}

Set& Set::operator=(const Set& other) {
	if (this == &other)
		return *this;

	this->dispose();
	this->arr = new Rectangle[other.arraySize];

	for (int i = 0; i < other.arraySize; i++)
		this->arr[i] = other.arr[i];

	this->capacity = other.capacity;
	this->arraySize = other.arraySize;

	return *this;

}

Set& Set::operator=(Set&& other) {
	if (this == &other)
		return *this;

	this->dispose();

	this->arr = other.arr;
	this->capacity = other.capacity;
	this->arraySize = other.arraySize;

	other.arr = nullptr;
	other.capacity = 0;
	other.arraySize = 0;

	return *this;
}

Set Set::add(const Rectangle& r) const {
	if (this->isInSet(r)) {
		std::cout << "Nemoguce dodati u set, vec postoji dati pravougaonik!" << std::endl;
		return *this;
	}
	else {
		Set s(*this);
		if (s.arraySize >= s.capacity) {
			s.realloc();
		}

		s.arr[s.arraySize] = r;
		s.arraySize++;

		return s;
	}
}

/*Set& Set::operator+=(const Rectangle& r) {
	if (this->isInSet(r)) {
		std::cout << "Nemoguce dodati u set, vec postoji dati pravougaonik!" << std::endl;
		return *this;
	}
	else {
		if (this->arraySize >= this->capacity) {
			this->realloc();
		}

		this->arr[this->arraySize] = r;
		this->arraySize++;

		return *this;
	}
}*/

/*Set& Set::operator-=(const Rectangle& r) {
	int index;
	if (this->arraySize == 0 || !this->isInSet(r, &index)) {
		std::cout << "Nemoguce ukloniti jer nema pravougaonika u nizu ili je niz prazan!" << std::endl;
		return *this;
	}
	else {
		this->isInSet(r, &index);
		for (int i = index; i < this->arraySize; i++) {
			this->arr[i] = this->arr[i + 1];
		}

		this->arraySize--;

		if (this->shouldShrink()) {
			this->realloc(this->arraySize);
		}

		return *this;
	}
}*/

Set& Set::operator+=(const Rectangle& r) {
	Set s = add(r);
	*this = s;
	return *this;
}

Set Set::operator+(const Rectangle& r) const{
	return add(r);
}

Set Set::remove(const Rectangle& r) const {
	int index;
	if (this->arraySize == 0 || !this->isInSet(r, &index)) {
		std::cout << "Nemoguce ukloniti jer nema pravougaonika u nizu ili je niz prazan!" << std::endl;
		return *this;
	}
	else {
		this->isInSet(r, &index);
		Set s(*this);
		for (int i = index; i < s.arraySize; i++) {
			s.arr[i] = s.arr[i + 1];
		}

		s.arraySize--;

		if (s.shouldShrink()) {
			s.realloc(s.arraySize);
		}

		return s;
	}
}

Set Set::operator-(const Rectangle& r) const {
	return remove(r);
}

Set& Set::operator-=(const Rectangle& r) {
	Set s = remove(r);
	*this = s;
	return *this;
}

bool Set::operator==(const Set& s) const{
	if (this->arraySize != s.arraySize) {
		std::cout << "Setovi nisu jednaki!" << std::endl;
		return false;
	}

	int br = 0;

	for (int i = 0; i < this->arraySize; i++) {
		for (int j = 0; j < this->arraySize; j++) {
			if (this->arr[i].getCoordinateA() == s.arr[j].getCoordinateA()
				&& this->arr[i].getCoordinateB() == s.arr[j].getCoordinateB()
				&& this->arr[i].getCoordinateC() == s.arr[j].getCoordinateC() 
				&& this->arr[i].getCoordinateD() == s.arr[j].getCoordinateD())
					br++;
		}	
	}
	//std::cout << br << std::endl;
	if (br == this->arraySize)
		return true;
	else
		return false;

}

void Set::realloc() {
	this->realloc(this->capacity > 0 ? this->capacity * 2 : 1);
}

void Set::realloc(int newCap) {
	Rectangle* newArray = new Rectangle[newCap]();
	this->capacity = newCap;
	this->arraySize = this->arraySize > this->capacity ? this->capacity : this->arraySize;
	for (int i = 0; i < this->arraySize; i++) {
		newArray[i] = this->arr[i];
	}
	this->dispose();
	this->arr = newArray;
}

void Set::dispose() {
	delete[] this->arr;
}

bool Set::isInSet(const Rectangle& r, int *index) const {
	for (int i = 0; i < this->arraySize; i++) {
		if (this->arr[i].getCoordinateA() == r.getCoordinateA() && this->arr[i].getCoordinateB() == r.getCoordinateB()
			&& this->arr[i].getCoordinateC() == r.getCoordinateC() &&
			this->arr[i].getCoordinateD() == r.getCoordinateD()) {
			*index = i;
			return true;
		}
	}

	return false;
}

bool Set::isInSet(const Rectangle& r) const {
	for (int i = 0; i < this->arraySize; i++) {
		if (this->arr[i].getCoordinateA() == r.getCoordinateA() && this->arr[i].getCoordinateB() == r.getCoordinateB()
			&& this->arr[i].getCoordinateC() == r.getCoordinateC() &&
			this->arr[i].getCoordinateD() == r.getCoordinateD()) {
			return true;
		}
	}

	return false;
}

bool Set::shouldShrink() const {
	return this->arraySize <= this->capacity / 2;
}

Set Set::copySet() const {
	return Set(this->arraySize, this->capacity, this->arr);
}

/*std::ostream& operator<<(std::ostream& os) const {

}*/