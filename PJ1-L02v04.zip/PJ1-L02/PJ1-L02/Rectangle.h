#include "Coordinates.h"

#pragma once

class Rectangle {
private:
	double a, b;
	Coordinate A;
	Coordinate B;
	Coordinate C;
	Coordinate D;
	//friend Coordinate;
	
public:
	Rectangle();
	Rectangle(Coordinate A, Coordinate B, Coordinate C, Coordinate D);
	//Rectangle(const Rectangle& other);

	Rectangle operator+(Rectangle r);
	Rectangle operator*(double X);
	Rectangle operator&(Rectangle r);

	double getA() const;
	double getB() const;
	Coordinate getCoordinateA() const;
	Coordinate getCoordinateB() const;
	Coordinate getCoordinateC() const;
	Coordinate getCoordinateD() const;
	Coordinate getCenter() const;
	void printRectangle() const;

private:
	bool condition(Coordinate A, Coordinate B, Coordinate C, Coordinate D) const;
	bool isInLine(Coordinate A, Coordinate B, Coordinate C, Coordinate D) const;
	bool areCoordinatesRight(Coordinate A, Coordinate B, Coordinate C, Coordinate D) const;
	bool doTheyOverlap(Rectangle r) const;
	double getArea() const;
	Rectangle helpForPlus(Rectangle r2) const;
	bool minmaxX() const;
	bool minmaxY() const;
};