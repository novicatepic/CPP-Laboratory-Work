#include <iostream>
#include <fstream>
#include "Graph.h"
#include "Person.h"
#include "Student.h"
#include "Nastavnik.h"

void demoGraph()
{
	UndirectedGraph<std::string> graph;

	graph.add(0, "0");
	graph.add(1, "1");
	//graph.connect(0, 1);

	//for (auto x : graph)
		//std::cout << x << ' ';

	auto printFunction = [](const std::string& str) {std::cout << str << ' '; };


	std::cout << std::endl;
	//graph.forEachBFS(0, printFunction);

	std::cout << std::endl;
	//graph.forEachBFS(1, printFunction);

	//graph.connect(1, 0);

	std::cout << std::endl;
	//graph.forEachBFS(1, printFunction);

	graph.add(2, "2");
	graph.connect(0, 2);
	graph.connect(0, 1);
	//graph.connect(1, 2);
	graph.add(3, "3");
	graph.connect(3, 1);
	graph.add(4, "4");
	graph.add(5, "5");
	//graph.connect(1, 4);
	graph.connect(1, 5);
	graph.connect(4, 5);
	graph.add(6, "6");
	graph.connect(6, 1);
	//graph.forEachDFS(1, printFunction);
	std::cout << std::endl;
	//graph.disconnect(3, 1);
	//graph.remove(0, "0");
	//graph.forEachDFS(1, printFunction);
	std::cout << std::endl;
	graph.remove(5, "5");
	//graph.forEachDFS(1, printFunction);
	std::cout << std::endl;
	graph.remove(4, "4");
	//graph.forEachDFS(1, printFunction);
	std::cout << std::endl;
	graph.remove(6, "6");
	// RADI KAD NE POZOVEMO .erase() U GRAFU, U SUPROTNOM GRESKA
	// ALI AKO NE POZOVEMO .erase(), GRESKA JE KAD ZELIMO KONEKTOVATI CVOR KOJI SMO NAPRAVILI A KOJI JE PRIJE POSTOJAO
	// SA BILO KOJIM DRUGIM CVOROM
	// DFS OBILAZAK KAO PRVOG "KOMSIJU" GLEDA ONAJ CVOR KOJI IMA NAJMANJI ID, NE STRING!
	//graph.add(0, "0");

	//graph.connect(0, 1);
	//graph.remove(0, "0");
	//graph.remove(8, "8");
	std::cout << std::endl;
	//graph.forEachDFS(1, printFunction);
	auto write = std::ofstream("upis.txt");

	write << graph;
	//write << graph;
	write.close();
	auto read = std::ifstream("upis.txt");
	UndirectedGraph<std::string> graph3;
	read >> graph3;
	graph.forEachDFS(2, printFunction);
	std::cout << std::endl;
	graph3.forEachDFS(2, printFunction);
	//graph3.connect(0, 1);
	//graph3.connect(1, 2);
	//graph3.connect(1, 3);
	//graph3.forEachDFS(0, printFunction);
	graph.add(8, "4");
	graph.add(9, "-2");
	graph.add(7, "19");
	graph.connect(8, 1);
	graph.connect(7, 1);
	graph.connect(9, 1);
	std::cout << std::endl;
	//graph3.forEachDFS(1, printFunction);
	read.close();
	

}

void demoGraph3() {
	auto printFunction = [](const int& i) {std::cout << i << ' '; };

	UndirectedGraph<int> graph;
	graph.add(0, 0);
	graph.add(1, 1);
	graph.add(2, 2);
	graph.add(3, 3);
	graph.add(4, 4);
	graph.add(5, 5);
	graph.add(6, 6);

	graph.connect(2, 1);
	graph.connect(0, 2);
	graph.connect(3, 1);
	graph.connect(4, 3);
	graph.connect(5, 1);
	graph.connect(3, 0);
	graph.connect(5, 6);
	graph.forEachDFS(3, printFunction);

	auto write = std::ofstream("upis.txt", std::ios::out);
	write << graph;
	write.close();
	UndirectedGraph<int> graphRead;
	//std::cout << std::endl;
	auto read = std::ifstream("upis.txt", std::ios::in);
	read >> graphRead;
	std::cout << std::endl;
	graphRead.forEachDFS(0, printFunction);
	read.close();
}

void demoGraph2() {
	Nastavnik n("Marko", "Markovic", "doc");
	Student p1("Novica", "Tepic", "1102/20");
	Student p2("Milan", "Milanovic", "1111/22");
	UndirectedGraph<Person> graph;

	auto printFunction = [](const Person& p) {std::cout << p << ' '; };

	graph.add(0, n);
	graph.add(1, p1);
	graph.add(2, p2);
	graph.connect(0, 1);
	//graph.disconnect(0, 1);
	graph.connect(0, 2);
	graph.connect(1, 2);
	//graph.remove(0, n);
	graph.forEachDFS(3, printFunction);
	std::cout << std::endl;
	auto write = std::ofstream("upis.txt");
	write << graph;
	write.close();

	UndirectedGraph<Person> graphPersonRead;
	auto read = std::ifstream("upis.txt");
	read >> graphPersonRead;
	//graphPersonRead.forEachDFS(2, printFunction);
	//graphPersonRead.remove(0, n);
	//graphPersonRead.add(3, n);
	//graphPersonRead.connect(3, 2);
	//graphPersonRead.connect(3, 1);
	graphPersonRead.forEachDFS(2, printFunction);
	read.close();
}

int main()
{

	demoGraph();
	//while(true)
	//demoGraph3();
	//while(true)
	//demoGraph2();
	
	//std::shared_ptr<int> p(new int(5));
	//std::cout << *p << std::endl;

	/*std::shared_ptr<int> p(new int(5));
	int* getP = p.get();
	std::cout << *getP << std::endl;

	std::shared_ptr<Person> person(new Person("Novica", "Tepic"));
	Person* getPerson = person.get();
	std::cout << *getPerson;*/

	//KOMENTAR1
	//KOMENTAR2
	//KOMENTAR3
	//KOMENTAR4//KOMENTAR5

	return 0;
}