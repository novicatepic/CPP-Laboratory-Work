#pragma once
#include "Person.h"
#include <string>

class Nastavnik : public Person {
private:
	std::string zvanje;

public:
	Nastavnik(std::string name, std::string lastName, std::string zvanje) : Person(name, lastName, typeid(*this).raw_name()) {
		this->zvanje = zvanje;
	}

	friend std::ostream& operator<<(std::ofstream& ofs, const Nastavnik& p) {
		return ofs << p.name << ',' << p.lastName << ',' << p.zvanje << std::endl;
	}

	friend std::istream& operator>>(std::ifstream& ifs, Nastavnik& p) {
		char delim = ',';
		std::getline(ifs, p.name, delim);
		std::getline(ifs, p.lastName, delim);
		std::getline(ifs, p.zvanje);
		ifs.ignore();
		return ifs;
	}
};