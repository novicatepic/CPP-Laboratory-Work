#pragma once
#include <functional>
#include <set>
#include <queue>
#include <map>
#include <vector>
#include "Concept.h"
#include <fstream>
#include <iostream>
#include <string>

template <typename T>
class UndirectedGraph
{
	using Id = int;
	struct Node
	{
		T value;
		Id id;

		//std::set<std::shared_ptr<Node>> neighbours;
		std::set<Node*> neighbours;	

		Node(Id id, const T& value) : value(value), id(id)
		{}
		class iterator
		{
			std::set<Id> visited;

			//std::vector<std::shared_ptr<Node>> toVisit;
			std::vector<Node*> toVisit;

			//std::shared_ptr<Node> currentNode;
			Node* currentNode;
		public:
			explicit iterator(Node* node) : currentNode(node) {}

			iterator& operator++()
			{
				//POMOCNA PROMJENLJIVA, STATIC JER NE ZELIMO DA SVAKI PUT BUDE 0 KAD UDJEMO
				static int itHelp = 0;

				for (auto neighbour : currentNode->neighbours)
					//PRVI USLOV DA SADRZI NEIGHBOUR ID, TJ DA MU JE TO KOMSIJA
					//DRUGI USLOV DA NIJE U CVOROVIMA KOJI SE TREBAJU POSJETITI
					if (!visited.contains(neighbour->id) && std::find(toVisit.begin(), toVisit.end(), neighbour) == toVisit.cend())
					{
						//toVisit.push_back(neighbour);
						//GET ENKAPSULACIJA
						toVisit.push_back(neighbour);
					}
				visited.emplace(currentNode->id);

				//SORTIRAMO UBACENE NOVE CVOROVE DA BISMO MOGLI POSJETITI ONOG PRVOG PO PRIORITETU
				//SORTIRAMO IH U OPADAJUCEM REDOSLIJEDU 
				//SORTIRAMO U OPADAJUCEM DA UZMEMO NAJMANJI SA KRAJA I DA GA POSJETIMO
				
				std::sort(toVisit.begin() + itHelp, toVisit.end(), [](const auto& a1, const auto& a2) {
					return a1->id > a2->id;
					});
				//VRSIMO POSJETU I AZURIRAMO POMOCNU PROMJENLJIVU ZA NAREDNU ITERACIJU
				if (!toVisit.empty())
				{
					currentNode = toVisit.back();
					toVisit.pop_back();
					itHelp = toVisit.size();
				}
				else
					currentNode = nullptr;
				return *this;

			}
			iterator operator++(int)
			{
				auto temp = *this;
				this->operator++();
				return temp;
			}
			bool operator!=(const iterator& other) const { return currentNode != other.currentNode; }
			bool operator==(const iterator& other) const { return currentNode == other.currentNode; }
			T& operator*() { return currentNode->value; }
		};
		iterator begin() { return iterator(this); }
		iterator end() { return iterator(nullptr); }
	};

	std::map<Id, std::shared_ptr<Node>> nodes;
	//std::map<Id, Node*> nodes;

	Id nextIndex = 0;
	std::vector<Id> vect;
public:
	//POKUSAJMO OVDJE SA PAMETNIM POKAZIVACEM
	void add(Id id, const T& value)
	{
		nodes.emplace(nextIndex, std::make_shared<Node>(id, value));

		//nodes.emplace(nextIndex, new Node(id, value));

		nextIndex++;
		auto iter = std::find(vect.cbegin(), vect.cend(), id);
		if (iter != vect.end()) {
			vect.erase(iter);
		}
	}

	//BRISE CVOR I SVE VEZE MEDJU CVOROVIMA, VAZNA NAPOMENA DA SE TAJ ISTI CVOR KASNIJE NE MOZE UPOTREBLJAVATI, SA ISTIM ID-OM
	void remove(Id id, const T& value) noexcept(false) {
		auto it = nodes.begin();
		//TRY-CATCH NIJE RADIO KAKO TREBA
		for (it = nodes.begin(); it != nodes.end(); ) {
			if (it->second->id == id && it->second->value == value) {
				vect.push_back(it->second->id);

				for (Id first = 0; first < nextIndex; first++) {
					if (std::find(vect.cbegin(), vect.cend(), first) == vect.end())
						disconnect(it->second->id, first);	
				}
				//OVO UZROKUJE GRESKU U SLUCAJU DA U MEINU OBRISEMO CVOR SA ID = 0, PA GA OPET KREIRAMO
				// TJ. UKOLIKO NAPRAVIMO VEZU IZMEDJU OPET KREIRANOG CVORA 0 I BILO KOJEG DRUGOG CVORA
				// BILO BI SMISLENIJE DA OVO POSTOJI U PROGRAMU, ALI ZBOG KORISNIKA U MEINU CEMO OVO KOMENTARISATI
				//KADA NE BI BILO ERASE, SMISLENIJE BI BILO KREIRANJE U MEINU, ALI SE NE BI MOGLA VRSITI SERIJALIZACIJA GRAFA
				//ONAKO KAKO JE ZAMISLJENO 
				//RAZLOG JE STO SE ISTE VRIJEDNOSTI VISE PUTA UPISU/OCITAJU IZ GRAFA
				nodes.erase(it);	
				break;
			}
			else {
				++it;
			}
		}
	}

	void connect(Id id1, Id id2)
	{
		//POMOCU GET ENKAPSULACIJA U OBICAN POKAZIVAC JER NEIGHBOURS TO I JESTE
		nodes[id1]->neighbours.emplace(nodes[id2].get());
		nodes[id2]->neighbours.emplace(nodes[id1].get());
	}

	void disconnect(Id id1, Id id2) {
		//POMOCU GET ENKAPSULACIJA U OBICAN POKAZIVAC
		nodes[id1]->neighbours.erase(nodes[id2].get());
		nodes[id2]->neighbours.erase(nodes[id1].get());
	}

	class iterator
	{
		decltype(nodes.begin()) mapIterator; //std::map<Id, Node*>::iterator mapIterator;
	public:
		iterator(decltype(mapIterator) mapIterator) : mapIterator(mapIterator) {}
		iterator& operator++() { ++mapIterator; return *this; }
		iterator operator++(int) { auto temp = mapIterator; ++mapIterator; return temp; }
		bool operator!=(const iterator& other) const { return mapIterator != other.mapIterator; }
		bool operator==(const iterator& other) const { return mapIterator == other.mapIterator; }
		T& operator*() { return mapIterator->second->value; }
	};
	iterator begin() { return nodes.begin(); }
	iterator end() { return nodes.end(); }
	void forEachDFS(Id id, const std::function<void(const T&)>& action)
	{
		for (auto value : *nodes[id])
			action(value);
	}

	friend std::ostream& operator<<(std::ofstream& ofs, const UndirectedGraph& g) {
		//AKO JE SERIJALIZABILAN
		if constexpr (SerializableOUT<T>) {

			for (auto it = g.nodes.begin(); it != g.nodes.end(); it++) {
				if (it->second.get() != nullptr) {
					//UPISUJU SE ID, VALUE
					ofs << it->second->id << ',';
					ofs << it->second->value;
					ofs << '!';
					int n = 0;

					for (auto neighbour : it->second->neighbours) {
						n++;
					}
					//UPISUJE SE BROJ KOMSIJA
					ofs << n << ',';

					//UPISUJU SE KOMSIJE
					for (auto neighbour : it->second->neighbours) {
						ofs << neighbour->id << '-';
					}
					ofs << '~';
				}
				
			}
		}					
		else
			static_assert(false, "Object can't be written into file");
		return ofs;
	}

	friend std::istream& operator>>(std::ifstream& ifs, UndirectedGraph& g) {
		if constexpr (SerializableIN<T>) {
			while (ifs.good()) {
				std::string help, help2, help3, n;
				//OCITAVA SE ID
				std::getline(ifs, help, ',');
				T value;
				//OCITAVA SE VALUE
				//AKO JE STRING, CITA SE DO NAREDNOG !
				if constexpr(std::is_base_of<std::string, T>::value) {
					std::getline(ifs, value, '!');
				}
				//AKO JE BILO KOJA DRUGA VRIJEDNOST, CITA SE STANDARDNO
				else {
					ifs >> value;
				}
				//AKO JE VRIJEDNOST KOJA NIJE U OVOM SLUCAJU STRING ILI NEKA OBJEKAT NEKE KLASE
				//IGNORISE SE ! JER NISMO TO RADILI U GETLINE
				if constexpr (std::is_floating_point<T>::value || std::is_integral<T>::value)
					ifs.ignore();
				//OCITAVA SE BROJ KOMSIJA
				std::getline(ifs, n, ',');
				int nNumber = 0;
				//AKO NISMO OCITALI PRAZAN STRING, PRETVARAMO BROJ KOMSIJA U INT
				if (n != "") {
					nNumber = std::stoi(n);
				}
				//CITAMO SVE KOMSIJE, SVAKI KOMSIJA JE ODVOJEN POMOCU -
				//NEBITNO DA LI JE KOMSIJA SA ID 100000 ILI 7, SADA RADI
				std::getline(ifs, help3, '~');
				//DODAJEMO CVOR KOJI SMO PRVI OCITALI UZ NJEGOVU VRIJEDNOST TIPA T
				if (help != "") {
					g.add(std::stoi(help), value);
				}
				int i = 0;

				//SVE DOK IMAMO KOMSIJA
				while (nNumber) {
					std::string concatNeighbours;
					//UZMEMO KOMSIJU
					//char getHelp = help3[i]; RADI(1)
					//PRESKOCIMO - KOJIM SMO ODVAJALI KOMSIJE, POTREBNA DORADA KASNIJE
					//i += 2; RADI(1)
					//NADJEMO KOJI JE TO KOMSIJA
					//int connect = getHelp - '0'; RADI(1)

					//SVE DOK JE KOMSIJA BROJ KONKATUJEMO STRING
					while (help3[i] - '0' >= 0 && help3[i] - '0' <= 9) {
						concatNeighbours += help3[i];
						++i;
					}
					++i;
					//SPOJIMO KOMSIJE SAMO UKOLIKO JE CONNECT < OD TRENUTNOG, JER KONEKT JOS NISMO NAPRAVILI
					//TE BI DOSLO DO GRESKE
					//if (connect < std::stoi(help))           RADI(1)
						//g.connect(std::stoi(help), connect); RADI(1)

					//SPAJAMO KOMSIJE
					if (std::stoi(concatNeighbours) < std::stoi(help)) {
						g.connect(std::stoi(help), std::stoi(concatNeighbours));

					}
					nNumber--;
					//UMANJIMO BROJAC

				}
			}
		}	
		else
			static_assert(false, "Object can't be read from file");
		return ifs;
	}
};
