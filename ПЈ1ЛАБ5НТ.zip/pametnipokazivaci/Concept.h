#pragma once
#include <iostream>
#include <fstream>

template<typename T>
concept SerializableIN = requires(std::ifstream& ifs, T & t) {
	{ifs >> t} -> std::convertible_to<std::istream&>;
};

template<typename T>
concept SerializableOUT = requires(std::ofstream & ofs, T & t) {
	{ofs << t} -> std::convertible_to<std::ostream&>;
};

template<typename T>
concept Serializable = SerializableIN<T> && SerializableOUT<T>;

