#pragma once
#include <string>
#include <fstream>
#include <iostream>

class Person {
protected:
	std::string name;
	std::string lastName;
	std::string tip;
public:
	Person(std::string name = "", std::string lastName = "", std::string tip = "") : name(name), lastName(lastName), tip(tip) {}

	bool operator==(const Person & other) {
		if (this->name == other.name && this->lastName == other.lastName)
			return true;
		return false;
	}

	friend std::ostream& operator<<(std::ostream& os, const Person& p) {
		os << p.name << ", " << p.lastName << ", " << p.tip << std::endl;
		return os;
	}

	friend std::ostream& operator<<(std::ofstream& ofs, const Person& p) {
		//p.writeToFile(ofs, p);
		return ofs << p.name << ',' << p.lastName << ',' << p.tip;
	}

	friend std::istream& operator>>(std::ifstream& ifs, Person& p) {
		char delim = ',';
		std::getline(ifs, p.name, delim);
		std::getline(ifs, p.lastName, delim);
		std::getline(ifs, p.tip, '!');
		//ifs.ignore();
		return ifs;
	}
};

