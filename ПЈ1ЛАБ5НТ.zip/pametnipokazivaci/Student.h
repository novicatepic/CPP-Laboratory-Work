#pragma once
#include "Person.h"

class Student : public Person {
private:
	std::string brIndeksa;
public:
	Student(std::string name, std::string lastName, std::string brIndeksa) : Person(name, lastName, typeid(*this).raw_name()) {
		this->brIndeksa = brIndeksa;
	}

	friend std::ostream& operator<<(std::ofstream& ofs, const Student& p) {
		return ofs << p.name << ',' << p.lastName << ',' << p.brIndeksa << std::endl;
	}

	friend std::istream& operator>>(std::ifstream& ifs, Student& p) {
		char delim = ',';
		std::getline(ifs, p.name, delim);
		std::getline(ifs, p.lastName, delim);
		std::getline(ifs, p.brIndeksa);
		ifs.ignore();
		return ifs;
	}

};