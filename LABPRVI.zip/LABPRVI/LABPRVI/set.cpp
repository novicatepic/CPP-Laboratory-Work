#include "Set.h"
#include <iostream>

Set::Set() : arr(nullptr), arrSize(0), cap(0) {}

Set::Set(int cap, int arrSize, int *arr) : cap(cap), arrSize(arrSize), arr(new int[arrSize]) {
	for (int i = 0; i < arrSize; i++) {
		this->arr[i] = arr[i];
	}
}

Set::Set(const Set& original) : cap(original.cap), arrSize(original.arrSize), arr(new int[original.arrSize]) {
	for (int i = 0; i < original.arrSize; i++) {
		arr[i] = original.arr[i];
	}
}

Set::~Set() {
	this->dispose();
}

bool Set::addToSet(int value) {
	if (isDuplicate(value)) {
		std::cout << "Ne mozete unijeti duplikat u set!" << std::endl;
		return false;
	}

	if (this->arrSize >= this->cap)
		this->realloc();

	this->arr[arrSize] = value;
	this->arrSize++;

	return true;
}

bool Set::addToSet(int value, int index) {
	if (isIndexOk(index) && !isDuplicate(value)) {
		if (this->arrSize >= this->cap) {
			this->realloc();
		}

		for (int i = this->arrSize; i > index; i--) {
			this->arr[i] = this->arr[i - 1];
		}

		this->arr[index] = value;

		this->arrSize++;

		return true;
	}

	std::cout << "Nepostojeca vrijednost ili neispravan indeks, ne moze se dodati u set!" << std::endl;
	return false;
}

bool Set::removeFromSet(int value) {
	if (isInSet(value)) {
		int index = returnIndex(value);
		for (int i = index; i < this->arrSize; i++) {
			this->arr[i] = this->arr[i + 1];
		}

		this->arrSize--;

		if (this->shouldShrink()) {
			realloc(this->arrSize);
		}

		return true;
	}


	std::cout << "Ne postoji data vrijednost u setu, ne moze se izbaciti element!" << std::endl;
	return false;
}

bool Set::removeFromSetAt(int index) {
	if (isIndexOk(index)) {
		for (int i = index; i < this->arrSize; i++) {
			this->arr[i] = this->arr[i + 1];
		}

		this->arrSize--;

		if (this->shouldShrink()) {
			realloc(this->arrSize);
		}

		return true;
	}


	std::cout << "Nepostojeci indeks, ne moze se izbaciti element!" << std::endl;
	return false;
}

bool Set::isInSet(int value) {
	for (int i = 0; i < this->arrSize; i++) {
		if (arr[i] == value) {
			return true;
		}
	}

	std::cout << "Trazeni broj se NE nalazi u setu!" << std::endl;
	return false;
}

void Set::printSet() {
	for (int i = 0; i < this->arrSize; i++) {
		std::cout << this->arr[i] << " ";
	}
	std::cout << std::endl;
}

bool Set::compareSets(Set s1, Set s2) {
	bool condition = (s1.arrSize == s2.arrSize);
	if (condition) {
		int numberOfSameElements = 0;
		for (int i = 0; i < s1.arrSize; i++) {
			for (int j = 0; j < s2.arrSize; j++) {
				if (s1.arr[i] == s2.arr[j])
					numberOfSameElements++;
			}
		}
		if (numberOfSameElements == s1.arrSize) {
			std::cout << "Setovi su jednaki!" << std::endl;
			return true;
		}
	}

	std::cout << "Setovi nisu jednaki!" << std::endl;
	return false;
}

/*bool Set::compareSets(int arr1[100], int arr2[100], int arr1Size, int arr2Size) {

	bool condition = (arr1Size == arr2Size);
	if (condition) {
		int numberOfSameElements = 0;
		for (int i = 0; i < arr1Size; i++) {
			for (int j = 0; j < arr2Size; j++) {
				if (arr1[i] == arr2[j])
					numberOfSameElements++;
			}
		}
		if (numberOfSameElements == (arr1Size)) {
			std::cout << "Setovi su jednaki!" << std::endl;
			return true;
		}
	}

	std::cout << "Setovi nisu jednaki!" << std::endl;
	return false;
}*/

int Set::returnIndex(int value) {
	if (isInSet(value)) {
		for (int i = 0; i < this->arrSize; i++) {
			if (this->arr[i] == value)
				return i;
		}
	}

	std::cout << "Niste unijeli ispravnu vrijednost, ne moze se vratiti validan indeks!" << std::endl;
	return -1;
}

bool Set::isDuplicate(int value) {
	for (int i = 0; i < this->arrSize; i++) {
		if (arr[i] == value)
			return true;
	}
	return false;
}

void Set::realloc() {
	this->realloc(this->cap > 0 ? this->cap * 2 : 1);
}

void Set::realloc(int newCap) {
	int* newArr = new int[newCap];
	this->cap = newCap;
	this->arrSize = this->cap > this->arrSize ? this->arrSize : this->cap;
	for (int i = 0; i < this->arrSize; i++) {
		newArr[i] = this->arr[i];
	}
	this->dispose();
	this->arr = newArr;
}

void Set::dispose() {
	delete[] this->arr;
}

bool Set::isIndexOk(int index) {
	if (index >= 0 && index <= this->arrSize - 1)
		return true;
	return false;
}

bool Set::shouldShrink() {
	return arrSize <= cap / 2;
}

/*int* Set::getArray() const {
	return this->arr;
}

int Set::getSize() const {
	return this->arrSize;
}*/
