#include "Set.h"
#include <iostream>

int main() {
	int* demoArray = new int[3];
	for (int i = 0; i < 3; i++) {
		demoArray[i] = i + 1;
	}

	Set s1;
	Set s2(3, 3, demoArray);

	s1.addToSet(2);
	s1.addToSet(4);
	s1.addToSet(6);
	s1.addToSet(2); //ispis greske za duplikat

	s1.removeFromSetAt(3); //ispis greske, nepostojeci indeks
	s1.removeFromSet(7); //ispis greske, ne postoji dati broj

	s1.printSet(); 
	s2.printSet();

	s1.addToSet(10, 1);
	s2.addToSet(11, 0);

	s1.addToSet(15, 100); //pogresan unos, ne postoji pozicija 100

	s1.printSet();
	s2.printSet();

	s1.removeFromSet(2);
	s2.removeFromSetAt(3);

	s1.printSet();
	s2.printSet();

	s1.isInSet(66); //ispis greske
	s1.isInSet(4);

	s1.compareSets(s1, s2); //nejednaki setovi

	Set s3;
	Set s4;
	s3.addToSet(16);
	s3.addToSet(1);
	s3.addToSet(17);
	s3.addToSet(2);
	s4.addToSet(17);
	s4.addToSet(2);
	s4.addToSet(1);
	s4.addToSet(16);

	s3.compareSets(s3, s4); //jednaki setovi

	delete[] demoArray;

	return 0;

}