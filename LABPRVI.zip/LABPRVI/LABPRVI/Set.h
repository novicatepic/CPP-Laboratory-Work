#pragma once

class Set {
private:
	int cap;
	int arrSize;
	int* arr;

public:
	Set();
	Set(int cap, int arrSize, int *arr);
	Set(const Set& original);
	~Set();
	bool addToSet(int value);
	bool addToSet(int value, int index);
	bool removeFromSet(int value);
	bool removeFromSetAt(int index);
	bool isInSet(int value);
	void printSet();
	bool compareSets(Set s1, Set s2);
	//bool compareSets(int *arr1, int *arr2, int arr1Size, int arr2Size);
	int returnIndex(int value);




private:
	bool isDuplicate(int value);

	void realloc();
	void realloc(int newSize);
	void dispose();

	bool isIndexOk(int index);
	bool shouldShrink();

	//int* getArray() const;
	//int getSize() const;
};

